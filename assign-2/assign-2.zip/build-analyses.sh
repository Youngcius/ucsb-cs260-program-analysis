#!/usr/bin/env bash

set -e

# assuming you used a Makefile
make
