#include "ast.h"
#include "visitor.h"

void NoneType::accept(Visitor* visitor) {
    visitor->visit_none_type(this);
}

void IntegerType::accept(Visitor* visitor) {
    visitor->visit_integer_type(this);
}

void StructType::accept(Visitor* visitor) {
    visitor->visit_struct_type(this);
}

void PointerType::accept(Visitor* visitor) {
    visitor->visit_pointer_type(this);
}

void FunctionType::accept(Visitor* visitor) {
    visitor->visit_function_type(this);
}

void NumOp::accept(Visitor* visitor) {
    visitor->visit_num_op(this);
}

void VarOp::accept(Visitor* visitor) {
    visitor->visit_var_op(this);
}

void AddrOf::accept(Visitor* visitor) {
    visitor->visit_addr_of(this);
}

void Alloc::accept(Visitor* visitor) {
    visitor->visit_alloc(this);
}

void Add::accept(Visitor* visitor) {
    visitor->visit_add(this);
}

void Sub::accept(Visitor* visitor) {
    visitor->visit_sub(this);
}

void Mul::accept(Visitor* visitor) {
    visitor->visit_mul(this);
}

void Div::accept(Visitor* visitor) {
    visitor->visit_div(this);
}

void Copy::accept(Visitor* visitor) {
    visitor->visit_copy(this);
}

void Eq::accept(Visitor* visitor) {
    visitor->visit_eq(this);
}

void Neq::accept(Visitor* visitor) {
    visitor->visit_neq(this);
}

void Lte::accept(Visitor* visitor) {
    visitor->visit_lte(this);
}

void Lt::accept(Visitor* visitor) {
    visitor->visit_lt(this);
}

void Gte::accept(Visitor* visitor) {
    visitor->visit_gte(this);
}

void Gt::accept(Visitor* visitor) {
    visitor->visit_gt(this);
}

void Gep::accept(Visitor* visitor) {
    visitor->visit_gep(this);
}

void Gfp::accept(Visitor* visitor) {
    visitor->visit_gfp(this);
}

void Load::accept(Visitor* visitor) {
    visitor->visit_load(this);
}

void Store::accept(Visitor* visitor) {
    visitor->visit_store(this);
}

void CallExt::accept(Visitor* visitor) {
    visitor->visit_call_ext(this);
}

void Branch::accept(Visitor* visitor) {
    visitor->visit_branch(this);
}

void Jump::accept(Visitor* visitor) {
    visitor->visit_jump(this);
}

void Ret::accept(Visitor* visitor) {
    visitor->visit_ret(this);
}

void CallDir::accept(Visitor* visitor) {
    visitor->visit_call_dir(this);
}

void CallIdr::accept(Visitor* visitor) {
    visitor->visit_call_idr(this);
}

void Block::accept(Visitor* visitor) {
    visitor->visit_block(this);
}

void Variable::accept(Visitor* visitor) {
    visitor->visit_variable(this);
}

void Function::accept(Visitor* visitor) {
    visitor->visit_function(this);
}

void Extern::accept(Visitor* visitor) {
    visitor->visit_extern(this);
}

void Struct::accept(Visitor* visitor) {
    visitor->visit_struct(this);
}

void Program::accept(Visitor* visitor) {
    visitor->visit_program(this);
}

NoneType::NoneType () {}
IntegerType::IntegerType::IntegerType () {}
StructType::StructType (Id* id) : id(id) {}
PointerType::PointerType (Type* base_type) : base_type(base_type) {}
FunctionType::FunctionType (std::vector<Type*>* param_types, Type* ret_type) : param_types(param_types), ret_type(ret_type) {}
NumOp::NumOp (long value) : value(value) {}
VarOp::VarOp (Id* id) : id(id) {}
AddrOf::AddrOf (Id* dest, Id* src) : dest(dest), src(src) {}
Alloc::Alloc (Id* dest, Op* size, Id* id) : dest(dest), size(size), id(id) {}
Copy::Copy (Id* dest, Op* op) : dest(dest), op(op) {}
Gep::Gep (Id* dest, Id* ptr, Op* offset) : dest(dest), ptr(ptr), offset(offset) {}
Gfp::Gfp (Id* dest, Id* ptr, Id* field) : dest(dest), ptr(ptr), field(field) {}
Load::Load (Id* dest, Id* ptr) : dest(dest), ptr(ptr) {}
Store::Store (Id* ptr, Op* op) : ptr(ptr), op(op) {}
CallExt::CallExt (Id* dest, Id* ext, std::vector<Op*>* args) : dest(dest), ext(ext), args(args) {}
Branch::Branch (Op* op, Id* left, Id* right) : op(op), left(left), right(right) {}
Jump::Jump (Id* id) : id(id) {}
Ret::Ret (Op* op) : op(op) {}
CallDir::CallDir (Id* dest, Id* f, std::vector<Op*>* args, Id* next) : dest(dest), f(f), args(args), next(next) {}
CallIdr::CallIdr (Id* dest, Id* fp, std::vector<Op*>* args, Id* next) : dest(dest), fp(fp), args(args), next(next) {}
Block::Block (Id* id, std::vector<Instruction*>* instructions, Terminal* terminal) : id(id), instructions(instructions), terminal(terminal) {}
Variable::Variable (Id* id, Type* type) : id(id), type(type) {}
Function::Function (Id* id, std::vector<Variable*>* params, Type* ret_type, std::vector<Variable*>* vars, std::vector<Block*>* blocks) : id(id), params(params), ret_type(ret_type), vars(vars), blocks(blocks) {}
Extern::Extern (Id* id, FunctionType* type) : id(id), type(type) {}
Struct::Struct (Id* id, std::vector<Variable*>* fields) : id(id), fields(fields) {}
Program::Program (void) : structs(new std::vector<Struct*>), globals(new std::vector<Variable*>), externs(new std::vector<Extern*>), functions(new std::vector<Function*>) {}