#pragma once
#include <memory>
#include <vector>
#include <string>

class Visitor;

typedef std::string Id;

struct Node {
    virtual void accept (Visitor* visitor) = 0;

    template <typename T>
    bool is() const {
        return dynamic_cast<reduce<T>::value*>(this) != nullptr;
    }
    
private:
    template<typename T>
    struct reduce {
        using value = const T;
    };

    template<typename T>
    struct reduce<T*> {
        using value = typename reduce<T>::value;
    };

    template<typename T>
    struct reduce<T&> {
        using value = typename reduce<T>::value;
    };
};

struct Type : Node {};
struct NoneType : Type {
    NoneType ();
    virtual void accept (Visitor* visitor);
};
struct IntegerType : Type {
    IntegerType ();
    virtual void accept (Visitor* visitor);
};
struct StructType : Type {
    Id* id;
    StructType (Id* id);
    virtual void accept (Visitor* visitor);
};
struct PointerType : Type {
    Type* base_type;
    PointerType (Type* base_type);
    virtual void accept (Visitor* visitor);
};
struct FunctionType : Type {
    std::vector<Type*>* param_types;
    Type* ret_type;
    FunctionType (std::vector<Type*>* param_types, Type* ret_type);
    virtual void accept (Visitor* visitor);
};

struct Op : Node {};
struct NumOp : Op {
    long value;
    NumOp (long value);
    virtual void accept (Visitor* visitor);
};
struct VarOp : Op {
    Id* id;
    VarOp (Id* id);
    virtual void accept (Visitor* visitor);
};

struct Instruction : Node {};

/* <dest> =` `$addrof` <src>*/
struct AddrOf : Instruction {
    Id* dest;
    Id* src;
    AddrOf (Id* dest, Id* src);
    virtual void accept (Visitor* visitor);
};

/* <dest> =` `$alloc` <src>*/
struct Alloc : Instruction {
    Id* dest;
    Op* size;
    Id* id;
    Alloc (Id* dest, Op* size, Id* id);
    virtual void accept (Visitor* visitor);
};

/* <dest> = $arith <aop> <left> <right> */
struct Arith : Instruction {
    Id* dest;
    Op* left;
    Op* right;
    Arith (Id* dest, Op* left, Op* right);
    Arith (void) = default;
};

struct Add : Arith {
    Add (Id* dest, Op* left, Op* right);
    Add (void) = default;
    virtual void accept (Visitor* visitor);
};
struct Sub : Arith {
    Sub (Id* dest, Op* left, Op* right);
    Sub (void) = default;
    virtual void accept (Visitor* visitor);
};
struct Mul : Arith {
    Mul (Id* dest, Op* left, Op* right);
    Mul (void) = default;
    virtual void accept (Visitor* visitor);
};
struct Div : Arith {
    Div (Id* dest, Op* left, Op* right);
    Div (void) = default;
    virtual void accept (Visitor* visitor);
};

/* <dest> = $cmp <rop> <left> <right> */
struct Cmp : Instruction {
    Id* dest;
    Op* left;
    Op* right;
    Cmp (Id* dest, Op* left, Op* right);
    Cmp (void) = default;
};

struct Eq : Cmp {
    Eq (Id* dest, Op* left, Op* right);
    Eq (void) = default;
    virtual void accept (Visitor* visitor);
};
struct Neq : Cmp {
    Neq (Id* dest, Op* left, Op* right);
    Neq (void) = default;
    virtual void accept (Visitor* visitor);
};
struct Lte : Cmp {
    Lte (Id* dest, Op* left, Op* right);
    Lte (void) = default;
    virtual void accept (Visitor* visitor);
};
struct Lt : Cmp {
    Lt (Id* dest, Op* left, Op* right);
    Lt (void) = default;
    virtual void accept (Visitor* visitor);
};
struct Gte : Cmp {
    Gte (Id* dest, Op* left, Op* right);
    Gte (void) = default;
    virtual void accept (Visitor* visitor);
};
struct Gt : Cmp {
    Gt (Id* dest, Op* left, Op* right);
    Gt (void) = default;
    virtual void accept (Visitor* visitor);
};


struct Copy : Instruction {
    Id* dest;
    Op* op;
    Copy (Id* dest, Op* op);
    virtual void accept (Visitor* visitor);
};

/* <dest> = $gep <ptr> <offset> */
struct Gep : Instruction {
    Id* dest;
    Id* ptr;
    Op* offset;
    Gep (Id* dest, Id* ptr, Op* offset);
    virtual void accept (Visitor* visitor);
};

/* <dest> = $gfp <ptr> <field> */
struct Gfp : Instruction {
    Id* dest;
    Id* ptr;
    Id* field;
    Gfp (Id* dest, Id* ptr, Id* field);
    virtual void accept (Visitor* visitor);
};

/* <dest> = $load <ptr> */
struct Load : Instruction {
    Id* dest;
    Id* ptr;
    Load (Id* dest, Id* ptr);
    virtual void accept (Visitor* visitor);
};

/* $store <ptr> <op> */
struct Store : Instruction {
    Id* ptr;
    Op* op;
    Store (Id* ptr, Op* op);
    virtual void accept (Visitor* visitor);
};

/* <dest> = $call_ext <f> (<args>) */
struct CallExt : Instruction {
    Id* dest;
    Id* ext;
    std::vector<Op*>* args;
    CallExt (Id* dest, Id* ext, std::vector<Op*>* args);
    virtual void accept (Visitor* visitor);
};

struct Terminal : Node {};

/* $branch <op> <left> <right> */
struct Branch : Terminal {
    Op* op;
    Id* left;
    Id* right;
    Branch (Op* op, Id* left, Id* right);
    virtual void accept (Visitor* visitor);
};

/* $jump <id> */
struct Jump : Terminal {
    Id* id;
    Jump (Id* id);
    virtual void accept (Visitor* visitor);
};

/* $ret <op> */
struct Ret : Terminal {
    Op* op;
    Ret (Op* op);
    virtual void accept (Visitor* visitor);
};

/* <dest> = $call_dir <f>(<args>...) then <next>*/
struct CallDir : Terminal {
    Id* dest;
    Id* f;
    std::vector<Op*>* args;
    Id* next;
    CallDir (Id* dest, Id* f, std::vector<Op*>* args, Id* next);
    virtual void accept (Visitor* visitor);
};

/* <dest> = $call_dir <fp>(<args>...) then <next>*/
struct CallIdr : Terminal {
    Id* dest;
    Id* fp;
    std::vector<Op*>* args;
    Id* next;
    CallIdr (Id* dest, Id* fp, std::vector<Op*>* args, Id* next);
    virtual void accept (Visitor* visitor);
};

struct Block : Node {
    Id* id;
    std::vector<Instruction*>* instructions;
    Terminal* terminal;
    Block (Id* id, std::vector<Instruction*>* instructions, Terminal* terminal);
    virtual void accept (Visitor* visitor);
};

struct Variable : Node {
    Id* id;
    Type* type;
    Variable (Id* id, Type* type);
    virtual void accept (Visitor* visitor);
};

struct Function : Node {
    Id* id;
    std::vector<Variable*>* params;
    Type* ret_type;
    std::vector<Variable*>* vars;
    std::vector<Block*>* blocks;
    Function (Id* id, std::vector<Variable*>* params, Type* ret_type, std::vector<Variable*>* vars, std::vector<Block*>* blocks);
    virtual void accept (Visitor* visitor);
};

struct Extern : Node {
    Id* id;
    FunctionType* type;
    Extern (Id* id, FunctionType* type);
    virtual void accept (Visitor* visitor);
};

struct Struct : Node {
    Id* id;
    std::vector<Variable*>* fields;
    Struct (Id* id, std::vector<Variable*>* fields);
    virtual void accept (Visitor* visitor);
};

struct Program : Node {
    std::vector<Struct*>* structs;
    std::vector<Variable*>* globals;
    std::vector<Extern*>* externs;
    std::vector<Function*>* functions;
    Program (void);
    virtual void accept (Visitor* visitor);
};