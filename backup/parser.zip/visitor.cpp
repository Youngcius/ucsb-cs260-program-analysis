#include "visitor.h"
#include "ast.h"

class PolyVisitor : public Visitor {
public:
    enum class NodeEnum {
        Null = 0,
        PointerType,
        IntegerType,
        StructType,
        FunctionType,
        NumOp,
        VarOp,
        AddrOf,
        Alloc,
        Add,
        Sub,
        Mul,
        Div,
        Copy,
        Gep,
        Gfp,
        Load,
        Store,
        CallExt,
        Branch,
        Jump,
        Ret,
        CallDir,
        CallIdr,
        Block,
        Variable,
        Function,
        Extern,
        Struct,
        Program
        };

        void visit_pointer_type(PointerType* node) {currNodeEnum = NodeEnum::PointerType;}
        void visit_integer_type(IntegerType* node) {currNodeEnum = NodeEnum::IntegerType;}
        void visit_struct_type(StructType* node) {currNodeEnum = NodeEnum::StructType;}
        void visit_function_type(FunctionType* node) {currNodeEnum = NodeEnum::FunctionType;}
        void visit_num_op(NumOp* node) {currNodeEnum = NodeEnum::NumOp;}
        void visit_var_op(VarOp* node) {currNodeEnum = NodeEnum::VarOp;}
        void visit_addr_of(AddrOf* node) {currNodeEnum = NodeEnum::AddrOf;}
        void visit_alloc(Alloc* node) {currNodeEnum = NodeEnum::Alloc;}
        void visit_add(Add* node) {currNodeEnum = NodeEnum::Add;}
        void visit_sub(Sub* node) {currNodeEnum = NodeEnum::Sub;}
        void visit_mul(Mul* node) {currNodeEnum = NodeEnum::Mul;}
        void visit_div(Div* node) {currNodeEnum = NodeEnum::Div;}
        void visit_copy(Copy* node) {currNodeEnum = NodeEnum::Copy;}
        void visit_gep(Gep* node) {currNodeEnum = NodeEnum::Gep;}
        void visit_gfp(Gfp* node) {currNodeEnum = NodeEnum::Gfp;}
        void visit_load(Load* node) {currNodeEnum = NodeEnum::Load;}
        void visit_store(Store* node) {currNodeEnum = NodeEnum::Store;}
        void visit_call_ext(CallExt* node) {currNodeEnum = NodeEnum::CallExt;}
        void visit_branch(Branch* node) {currNodeEnum = NodeEnum::Branch;}
        void visit_jump(Jump* node) {currNodeEnum = NodeEnum::Jump;}
        void visit_ret(Ret* node) {currNodeEnum = NodeEnum::Ret;}
        void visit_call_dir(CallDir* node) {currNodeEnum = NodeEnum::CallDir;}
        void visit_call_idr(CallIdr* node) {currNodeEnum = NodeEnum::CallIdr;}
        void visit_block(Block* node) {currNodeEnum = NodeEnum::Block;}
        void visit_variable(Variable* node) {currNodeEnum = NodeEnum::Variable;}
        void visit_function(Function* node) {currNodeEnum = NodeEnum::Function;}
        void visit_extern(Extern* node) {currNodeEnum = NodeEnum::Extern;}
        void visit_struct(Struct* node) {currNodeEnum = NodeEnum::Struct;}
        void visit_program(Program* node) {currNodeEnum = NodeEnum::Program;}

        NodeEnum getNodeEnum(Node* node){
        if (node) {
            node->accept(this);
            return currNodeEnum;
        } else {
            return NodeEnum::Null;
        }
        }
private:
    NodeEnum currNodeEnum;
};