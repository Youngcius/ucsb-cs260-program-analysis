#include "ast.h"
#include <iostream>
#include <parser.h>

Program *root;

extern int yylex(void);
extern int yydebug;
int main() {
  yydebug = 0;
  yyparse();

  int numStructFields = 0;
  for (auto elem : *(root->structs)) {
    numStructFields += elem->fields->size();
  }

  std::cout << "Number of fields across all struct types: " << numStructFields
            << std::endl;

  int numRetFuncs = 0;
  int numFuncParams = 0;
  int numLocVars = 0;
  int numBasicBlocks = 0;
  int numInstructions = 0;

  int numIntType = 0;
  int numStructType = 0;
  int numPointerIntType = 0;
  int numPointerStructType = 0;
  int numPointerFuncType = 0;
  int numPointerPointerType = 0;

  for (auto elem : *(root->globals)) {
    if (elem->type->is<IntegerType>()) {
      numIntType++;
    } else if (elem->type->is<StructType>()) {
      numStructType++;
    } else if (elem->type->is<PointerType>()) {
      PointerType *currType = dynamic_cast<PointerType *>(elem->type);
      if (currType->base_type->is<IntegerType>()) {
        numPointerIntType++;
      } else if (currType->base_type->is<StructType>()) {
        numPointerStructType++;
      } else if (currType->base_type->is<FunctionType>()) {
        numPointerFuncType++;
      } else if (currType->base_type->is<PointerType>()) {
        numPointerPointerType++;
      }
    }
  }

  for (auto elem : *(root->functions)) {
    if (!elem->ret_type->is<NoneType>()) {
      numRetFuncs++;
    }

    numFuncParams += elem->params->size();
    numLocVars += elem->vars->size();
    numBasicBlocks += elem->blocks->size();
    for (auto block : *elem->blocks) {
      numInstructions += block->instructions->size();
    }

    for (auto local : *elem->vars) {
      if (local->type->is<IntegerType>()) {
        numIntType++;
      } else if (local->type->is<StructType>()) {
        numStructType++;
      } else if (local->type->is<PointerType>()) {
        PointerType *currType = dynamic_cast<PointerType *>(local->type);
        if (currType->base_type->is<IntegerType>()) {
          numPointerIntType++;
        } else if (currType->base_type->is<StructType>()) {
          numPointerStructType++;
        } else if (currType->base_type->is<FunctionType>()) {
          numPointerFuncType++;
        } else if (currType->base_type->is<PointerType>()) {
          numPointerPointerType++;
        }
      }
    }
  }
  std::cout << "Number of functions that return a value: " << numRetFuncs
            << std::endl;
  std::cout << "Number of function parameters: " << numFuncParams << std::endl;
  std::cout << "Number of local variables: " << numLocVars << std::endl;
  std::cout << "Number of basic blocks: " << numBasicBlocks << std::endl;
  std::cout << "Number of instructions: " << numInstructions << std::endl;
  std::cout << "Number of terminals: " << numBasicBlocks << std::endl;
  std::cout << "Number of locals and globals with int type: " << numIntType << std::endl;
  std::cout << "Number of locals and globals with struct type: " << numStructType << std::endl;
  std::cout << "Number of locals and globals with pointer to int type: " << numPointerIntType << std::endl;
  std::cout << "Number of locals and globals with pointer to struct type: " << numPointerStructType << std::endl;
  std::cout << "Number of locals and globals with pointer to function type: " << numPointerFuncType << std::endl;
  std::cout << "Number of locals and globals with pointer to pointer type: " << numPointerPointerType << std::endl;
}